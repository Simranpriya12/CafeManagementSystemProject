import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author Simran
 */
public class CafeManagementSystem1 { 
    public static void main(String[] args) {
       try {
           Class.forName("com.mysql.cj.jdbc.Driver");
           Connection con;
           try {
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","");
               System.out.println(con);
           } catch (SQLException ex) {
               Logger.getLogger(CafeManagementSystem1.class.getName()).log(Level.SEVERE,null,ex);
           }
       }
       catch(ClassNotFoundException ex) {
           Logger.getLogger(CafeManagementSystem1.class.getName()).log(Level.SEVERE,null,ex);
               
       }
    }    
          }
      
   
    

